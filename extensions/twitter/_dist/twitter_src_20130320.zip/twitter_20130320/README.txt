This is an extension module to xmlsh
This version requires xmlsh version 1.1.9 or greater


Import the twitter extension in xmlsh with an "import module" statement.

e.g.
   XMODPATH=/usr/local/xmlsh/ext
   import module twitter
   
or
   import module /usr/local/xmlsh/ext/twitter/module.xml
   


Full documentation on using the Twitter extension module is at

http://www.xmlsh.org/ModuleTwitter



Installation and getting started instructions for XMLSH are available at 

http://www.xmlsh.org

The "Quick Start" has directions on how to get up and running

http://www.xmlsh.org/QuickStart

